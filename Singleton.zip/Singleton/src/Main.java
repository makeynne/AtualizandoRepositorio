
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		FabricaAcer notebook = FabricaAcer.getInstancia();
		
		notebook.modelo="Aspire 11";
		notebook.geracao = " Core i5 Kabe Lake (7� Gera��o)";
		
		System.out.println("Fabrica da Acer \n Linha: "+notebook.modelo + "\n Modelo: "+notebook.geracao);
		System.out.println("\n");
		
		FabricaDell notebook2 = FabricaDell.getInstancia();
		
		notebook2.modelo="Inspiron 15";
		notebook2.geracao=" Core i5 Kabe Lake (7� Gera��o)";
		
		
		System.out.println("Fabrica da Dell \n Linha: "+notebook2.modelo + "\n Modelo: "+notebook2.geracao);

	}
	
	


}
