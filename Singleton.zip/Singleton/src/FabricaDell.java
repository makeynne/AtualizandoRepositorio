
public class FabricaDell {

	public static FabricaDell instancia;
	
	protected String modelo;
	protected String geracao;
	
	protected FabricaDell(){
		
	}
	
	public static FabricaDell getInstancia() {
		if(instancia==null) {
			instancia = new FabricaDell();
		} return instancia;
	}
}
