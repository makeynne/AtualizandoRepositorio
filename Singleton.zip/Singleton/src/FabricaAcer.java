
public class FabricaAcer {
	
	public static FabricaAcer instancia;
	
	protected String modelo;
	protected String geracao;
	
	protected FabricaAcer() {
		
	}

	
	public static FabricaAcer getInstancia() {
		if(instancia==null) {
			instancia = new FabricaAcer();
		} return instancia;
	}
}
