package padr�oBridgeColor;

public class CorVerde implements Cor{
	public void aplicarCor() {
		System.out.println("Verde.");
	}

}
