package padr�oBridgeColor;

public interface Cor {
	public void aplicarCor();

}
