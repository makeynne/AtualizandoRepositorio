package padr�oBridgeColor;

public class CorVermelha implements Cor{
	public void aplicarCor() {
		System.out.println("Vermelho.");
	}
}
