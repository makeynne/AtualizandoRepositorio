package calcula;

import java.util.Scanner;

public class CalcChamada {
	

	 static void chamada() {
		 

}}
