package calcula;


public class BinarioA extends Calculadora {

    public void DecimalBinario(Integer restante) {
        System.out.println("Binario: " + Integer.toString(restante, 2));
    }
}
