package calcula;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
    	
    	int restante = 0;
        String restantetart;

        Scanner scanner = new Scanner(System.in);
        System.out.println("Escolha a operacao " +
                "\n 1 [+] " +
                "\n 2 [-] " +
                "\n 3 [*] " +
                "\n 4 [/] " +
                "\n Digite o numero da operacao:\n");

        	int whatever = scanner.nextInt();
        	int adicao = 1;
        	int subtracao = 2;
        	int multiplicacao = 3;
        	int divisao = 4;

        	BinarioA binarioA = new BinarioA();
        	OctadecimalA octadecimalA = new OctadecimalA();
        	HexadecimalA hexadecimalA = new HexadecimalA();

        if (whatever == adicao) {
            Calculadora sum = new Calculadora();
            restante = sum.adicao();
            binarioA.DecimalBinario(restante);
            octadecimalA.DecimalOctadecimal(restante);
            hexadecimalA.DecimalHexadecimal(restante);
        } else if (whatever == subtracao) {
            Calculadora sub = new Calculadora();
            restante = sub.subtracao();
            binarioA.DecimalBinario(restante);
            octadecimalA.DecimalOctadecimal(restante);
            hexadecimalA.DecimalHexadecimal(restante);
        } else if (whatever == multiplicacao) {
            Calculadora mult = new Calculadora();
            restante = mult.multiplicacao();
            binarioA.DecimalBinario(restante);
            octadecimalA.DecimalOctadecimal(restante);
            hexadecimalA.DecimalHexadecimal(restante);
        } else if (whatever == divisao) {
            Calculadora div = new Calculadora();
            restante = div.divisao();
            binarioA.DecimalBinario(restante);
            octadecimalA.DecimalOctadecimal(restante);
            hexadecimalA.DecimalHexadecimal(restante);
        } else {
            System.out.println("A113!");
        }

        System.out.println("Calcular novamente? [sim] ou [N] ? \n");
        restantetart = scanner.next();

        if (restantetart.equals("sim") || restantetart.equals("Sim")) {
            main(args);
        } else {
            System.exit(0);
        }

       
    }
}

