package calcula;

import java.util.Scanner;

public class Calculadora {
	//padr�o de calculadora

    int pn, sn, restante = 0;

    public int adicao() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o primeiro numero: \n");
        pn = scanner.nextInt();
        System.out.println("Digite o segundo numero: \n");
        sn = scanner.nextInt();

        restante = pn + sn;

        System.out.println("Decimal: " + pn + " + " + sn + " = " + restante + "\n");
        return restante;
    }

    public int subtracao() {
    	
    	
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o primeiro numero: \n");
        pn = scanner.nextInt();
        System.out.println("Digite o segundo numero: \n");
        sn = scanner.nextInt();

        restante = pn - sn;

        System.out.println("Decimal: " + pn + " - " + sn + " = " + restante + "\n");
        return restante;
    }

    public int multiplicacao() {
    	
    	
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o primeiro numero: \n");
        pn = scanner.nextInt();
        System.out.println("Digite o segundo numero: \n");
        sn = scanner.nextInt();

        restante = pn * sn;

        System.out.println("Decimal: " + pn + " * " + sn + " = " + restante + "\n");
        return restante;
    }

    public int divisao() {
    	
    	
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o primeiro numero: \n");
        pn = scanner.nextInt();
        System.out.println("Digite o segundo numero: \n");
        sn = scanner.nextInt();

        restante = pn / sn;

        System.out.println("Decimal: " + pn + " / " + sn + " = " + restante + "\n");
        return restante;
    }

}
