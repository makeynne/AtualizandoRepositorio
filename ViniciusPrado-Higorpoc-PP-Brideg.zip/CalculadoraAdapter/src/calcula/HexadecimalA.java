package calcula;

public class HexadecimalA extends Calculadora {

    public void DecimalHexadecimal(Integer restante) {
        System.out.println("Hexadecimal: " + Integer.toString(restante, 16));
    }


}
