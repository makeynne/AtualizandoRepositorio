package calcula;

public class OctadecimalA extends Calculadora {

    public void DecimalOctadecimal(Integer restante) {
        System.out.println("Octal: " + Integer.toString(restante, 8));
    }
}
