package SmartphoneFM;

public class Xperia extends Smartphone{
	
	public Xperia(String modelo) {
		this.modelo = modelo;
		System.out.println("Seu Smartphone � um Xperia "+this.modelo);
	}

}


