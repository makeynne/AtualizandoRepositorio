package SmartphoneFM;

public class Samsung extends Smartphone{
	
	public Samsung(String modelo) {
		this.modelo = modelo;
		System.out.println("Seu Smartphone � um Sansung Galaxy "+this.modelo);
	}

}
