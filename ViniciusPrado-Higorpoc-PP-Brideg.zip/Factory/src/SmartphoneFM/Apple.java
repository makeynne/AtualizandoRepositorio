package SmartphoneFM;

public class Apple extends Smartphone{
	
	public Apple(String modelo) {
		this.modelo = modelo;
		System.out.println("Seu Smartphone � um Apple Iphone "+this.modelo);
	}

}
