package SmartphoneFM;

public abstract class Smartphone {

	public String marca;
	public String modelo;
	
	
	
	
	
}
