package br;

public class Guirlanda extends Decoracao {

private ArvoreDeNatal arvore;
	
	public Guirlanda(ArvoreDeNatal arvore) {
		this.arvore = arvore;
	}
	
	public void beleza() {
		arvore.beleza();
		System.out.println("thuummmm...");
	}
}
