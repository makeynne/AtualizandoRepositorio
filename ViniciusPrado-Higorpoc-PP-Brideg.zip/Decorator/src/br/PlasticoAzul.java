package br;

public class PlasticoAzul extends ArvoreDeNatal {

	@Override
	public void beleza() {
		System.out.println("inhaaackkky...");
	}

}
