package br;

public class NoiteFeliz {
	
	private ArvoreDeNatal arvore;
	
	public NoiteFeliz()  {
		arvore = new Pinheirinho();
		arvore = new Estrela(arvore);
		arvore = new Guirlanda(arvore);
		arvore = new  Piscapisca (arvore);		
		dingowbellCaralheon(arvore);
	}
	
	public void dingowbellCaralheon(ArvoreDeNatal arvore) {
		arvore.beleza();
	}
}