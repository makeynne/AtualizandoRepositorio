package br;

public class Piscapisca extends Decoracao {

private ArvoreDeNatal arvore;
	
	public Piscapisca(ArvoreDeNatal arvore) {
		this.arvore = arvore;
	}
	
	public void beleza() {
		arvore.beleza();
		System.out.println("Thummmmm...");
	}

}
