package br;

public abstract class ArvoreDeNatal {
	
	public abstract void beleza();
}
