package br;

public abstract class Decoracao extends ArvoreDeNatal {
	
	
}
