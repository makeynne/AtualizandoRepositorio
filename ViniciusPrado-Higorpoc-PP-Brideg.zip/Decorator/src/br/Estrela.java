package br;

public class Estrela extends Decoracao {
	
	private ArvoreDeNatal arvore;
	
	public Estrela(ArvoreDeNatal arvore) {
		this.arvore = arvore;
	}
	
	public void beleza() {
		arvore.beleza();
		System.out.println("haaaaaaaa...");
	}

}
