package br;

public class Pinheirinho extends ArvoreDeNatal {

	@Override
	public void beleza() {
		System.out.println("noffann");

	}

}
