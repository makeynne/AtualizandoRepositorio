package br;

public class Launch {

	public static void main(String[] args) {
		
		new NoiteFeliz();
	}

}
